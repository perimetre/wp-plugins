<?php

class WPML_Manage_Translations_Role {
	const CAPABILITY = 'manage_translations';

}
