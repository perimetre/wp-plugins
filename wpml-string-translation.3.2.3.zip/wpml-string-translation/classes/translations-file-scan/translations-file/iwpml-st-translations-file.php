<?php

interface IWPML_ST_Translations_File {

	/**
	 * @return WPML_ST_Translations_File_Translation[]
	 */
	public function get_translations();
}
