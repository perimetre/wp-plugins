# Clone Field

The clone field is not fully supported (yet). We plan to support it in the future.

----

- **Previous Field:** [Checkbox](./checkbox.md)
- **Next Field:** [Color Picker](./color-picker.md)

